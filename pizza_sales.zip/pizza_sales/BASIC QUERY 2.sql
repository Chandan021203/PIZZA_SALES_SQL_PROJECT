			--  Calculate the total revenue generated from pizza sales.
		
        CREATE VIEW TOTAL_REVENUE AS
        SELECT ROUND(SUM(order_details.Quantity * pizzas.price),2) AS Total_Revenue
		FROM order_details
        JOIN pizzas ON pizzas.pizza_id = Order_Details.Pizza_id;
    
    
			--  Calculate the total revenue generated from pizza sales.
		
        SELECT * FROM TOTAL_REVENUE;