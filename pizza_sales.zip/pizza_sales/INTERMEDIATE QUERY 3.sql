	-- Join relevant tables to find the category-wise distribution of pizzas.
		SELECT CATEGORY,COUNT(pizza_type_id) AS TOTAL_PIZZAS FROM pizza_types
		GROUP BY category;
        