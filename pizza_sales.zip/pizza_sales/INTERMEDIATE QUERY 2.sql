	-- Determine the distribution of orders by hour of the day.
		CREATE VIEW ORDERS_PER_HOUR AS
        SELECT hour(time) AS HOURS , COUNT(order_id) AS ORDER_COUNT FROM orders
		GROUP BY HOURS
		ORDER BY HOURS ASC;
        
	-- Determine the distribution of orders by hour of the day.  
        SELECT * FROM ORDERS_PER_HOUR;