	-- Analyze the cumulative revenue generated over time.

		SELECT ORDER_DATE,
		ROUND(SUM(Revenue) OVER(ORDER BY ORDER_DATE),2) AS Cum_Revenue
		FROM
		(SELECT orders.date AS ORDER_DATE,
		SUM(order_details.quantity * pizzas.price) AS Revenue
		FROM order_details
		JOIN pizzas ON order_details.pizza_id = pizzas.pizza_id
		JOIN orders ON orders.order_id = order_details.order_id
		GROUP BY orders.date) AS Sales;

