	-- Group the orders by date and calculate the average number of pizzas ordered per day.
		
        SELECT ROUND(AVG(Quantity),0) AS Average_Quantity_Per_Day FROM
        (SELECT DATE(orders.date) AS DATES,SUM(order_details.Quantity) AS Quantity FROM orders
        JOIN order_details ON order_details.Order_id = orders.order_id
        GROUP BY orders.date) AS Order_Quantity;