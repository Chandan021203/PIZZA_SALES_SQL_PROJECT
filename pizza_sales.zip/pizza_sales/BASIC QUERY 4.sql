	-- Identify the most common pizza size ordered.
			CREATE VIEW COMMON_PIZZA_SIZE AS
			SELECT pizzas.size,count(order_details.order_details_id) AS Order_Count FROM pizzas
            JOIN order_details ON pizzas.pizza_id=order_details.Pizza_id
            GROUP BY pizzas.size
            ORDER BY Order_Count DESC
            LIMIT 1;
            
            
	-- Identify the most common pizza size ordered.
            SELECT * FROM COMMON_PIZZA_SIZE;