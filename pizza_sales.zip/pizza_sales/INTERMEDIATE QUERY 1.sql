	-- Join the necessary tables to find the total quantity of each pizza category ordered.

			CREATE VIEW Category_Quantity AS
            SELECT pizza_types.category AS PIZZA_CATEGORY,
            SUM(order_details.Quantity) AS TOTAL_QUANTITY FROM pizza_types
            JOIN pizzas ON pizza_types.pizza_type_id = pizzas.pizza_type_id 
            JOIN order_details ON order_details.Pizza_id = pizzas.pizza_id
            GROUP BY pizza_types.category
            ORDER BY TOTAL_QUANTITY DESC;

	-- Join the necessary tables to find the total quantity of each pizza category ordered.
			SELECT * FROM Category_Quantity;
