	--  Identify the highest-priced pizza.
				
                CREATE VIEW HIGHEST_PRICE_PIZZA AS
				SELECT pizza_types.name, pizzas.price
				FROM pizza_types
				JOIN pizzas ON pizza_types.pizza_type_id = pizza_types.pizza_type_id
				ORDER BY pizzas.price DESC
				LIMIT 1;

	--  Identify the highest-priced pizza.	
				
                SELECT * FROM highest_price_pizza;