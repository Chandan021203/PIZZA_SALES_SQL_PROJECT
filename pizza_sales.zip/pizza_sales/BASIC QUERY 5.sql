		-- List the top 5 most ordered pizza types along with their quantities.
			CREATE VIEW Order_Quantity AS
            SELECT pizza_types.name AS PIZZA_NAME,
            SUM(order_details.Quantity) AS TOTAL_QUANTITY FROM pizza_types
            JOIN pizzas ON pizza_types.pizza_type_id = pizzas.pizza_type_id 
            JOIN order_details ON order_details.Pizza_id = pizzas.pizza_id
            GROUP BY pizza_types.name
            ORDER BY TOTAL_QUANTITY DESC
            LIMIT 5;
             
		-- List the top 5 most ordered pizza types along with their quantities.
             SELECT * FROM Order_Quantity;