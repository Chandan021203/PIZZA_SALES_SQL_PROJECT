	--  Retrieve the total number of orders placed.
		
        CREATE VIEW Total_Placed_Orders AS
		SELECT COUNT(order_id) FROM ORDERS;

	-- Retrieve the total number of orders placed.
		
        SELECT * FROM Total_Placed_Orders;
