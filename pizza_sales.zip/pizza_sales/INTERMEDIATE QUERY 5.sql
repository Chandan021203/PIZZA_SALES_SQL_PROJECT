	-- Determine the top 3 most ordered pizza types based on revenue. 
			SELECT pizza_types.name,
			SUM(order_details.quantity*pizzas.price) AS Revenue FROM pizza_types
			JOIN pizzas ON pizzas.pizza_type_id = pizza_types.pizza_type_id
			JOIN order_details ON order_details.Pizza_id = pizzas.Pizza_id
			GROUP BY pizza_types.name
			ORDER BY Revenue DESC
			LIMIT 3;
